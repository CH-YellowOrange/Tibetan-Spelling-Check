import tkinter as tk
from utils import BoCheckApp


if __name__ == "__main__":
    root = tk.Tk()
    app = BoCheckApp(root)
    root.mainloop()
